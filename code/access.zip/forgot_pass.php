<!doctype html>
<html>
<head>
<meta charset='utf-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<title>e&mdash;access Card</title>
<link href='#' rel='stylesheet'>
<link href='#' rel='stylesheet'>
<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
<link href='https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css' rel='stylesheet'>
<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
<style>::-webkit-scrollbar {
  width: 8px;
}
/* Track */
::-webkit-scrollbar-track {
  background: #f1f1f1; 
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: #888; 
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #555; 
} body{
  background: #2962FF;
  font-family: Arial, Helvetica, sans-serif;
}



.card-heading, .card-subheading{
  font-weight: bold;
}
.card{
  width: 450px;

  border: none;
  border-radius: 10px;  
}
.form-control{
  border: none;
  border-radius: 10px;
  
}
.fone{
  padding-left: 30px;

}

.form-control{
    background-color:#eee !important;
}

.form-control:focus {
    color: #495057;
   
    border-color: #fff !important;
    outline: 0;
    box-shadow: 0 0 0 0 rgba(0,123,255,.25) !important;
}

.fone input{
      width: 120%;
     background: rgba(165, 147, 69, 0.075);
     
}
.ftwo input{
      width: 120%;
      background: rgba(165, 147, 69, 0.075);
}

.fthree{
  padding-left: 30px;
  padding-right: 45px;
}
.fthree input{
  background-color: rgba(165, 147, 69, 0.075);
}
.ffour{
  padding-left: 30px;
}

.ffour input{
      width: 120%;
      background-color: rgba(165, 147, 69, 0.075);
}
.ffive input{
      width: 120%;
      background-color: rgba(165, 147, 69, 0.075);
  }
.rthree{
  padding-top: 1px;
}
.para1{
  height: 10px;
  font-size: 12px;
}
.para2{
  font-size: 12px;
}
.btn-primary{
  border-radius: 8px;
  background: #2979FF;
  width: 120px;
}
.btn-primary span{
  font-size: 15px;
}

@media screen and (max-width: 768px){
.fone input{
      width: 90%;
}
.ftwo input{
      width: 86%;
}
.fthree{
  width: 110%;
}
.ffour input{
      width: 90%;
}
.ffive input{
      width: 86%;
}
}

.error{
  color: red;
  text-align: center;
  align-content: center;
  justify-content: center;
  align-self: center;
}
</style>
</head>
  <body className='snippet-body'>
    <div class="container d-flex justify-content-center">
  <div class="card mx-5 my-5">
    <div class="card-body px-2">
      <h2 class="card-heading px-3">Sign In</h2>
      <h5 class="card-subheading px-3 pb-3">It's quick and easy.</h5>
      <?php
      session_start();
      include 'connector.php';
          // define variables and set to empty values


      $ini=$erini=$surname=$ersurname=$email=$eremail=$campus=$ercampus=$user_type=$eruser_type=$staff_no=$erstaff_no=$stud_no=$erstud_no=$pwd=$erpwd=$cpwd=$ercpwd=$hashp=$ermy_photo=$my_photo="";
        $Tini=$Tsurname=$Temail=$Tcampus=$Tuser_type=$Tstaff_no=$Tstud_no=$Tpwd=$Tcpwd=$Tmy_photo=false;
        
     
        if (isset($_POST['register'])) {
           

       if (empty($_POST["email"])) {
          $eremail= "Email is required";
          $Temail=false;
        } else {
          $email = test_input($_POST["email"]);
          $Temail=true;
          // check if e-mail address is well-formed
          if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $eremail= "Invalid email format";
            $Temail=false; 
          }else{
              $query="SELECT * FROM user WHERE email='$email'";
              $result=mysqli_query($conn,$query);
               if(!$result){

                die("db access failed ".mysqli_error($conn));
              }
                //get the number of rows of the executed query  
              $rows=mysqli_num_rows($result);
                          
        if($rows>0){
                  $eremail ="email already registered";
                  $Temail=false;
              }
          }
        
         }
         

         if (empty($_POST["campus"])) {
          $ercampus = "Campus is required";
          $Tcampus=false;
        } else {
          $campus = test_input($_POST["campus"]);
          $Tcampus=true;

          }
          
          //1st password
        if (empty($_POST["pwd"])) {
          $erpwd = "Password is required";
          $Tpwd=false;
        } else {
          $pwd = test_input($_POST["pwd"]);
          $Tpwd=true;

              if(strlen($pwd)<8){
                  $erpwd = "password must have at least 8 digits";
                  $Tpwd=false;
                  
              }
          }
          
        
          
         //2nd password 
       if (empty($_POST["cpwd"])) {
          $ercpwd = "Password confirm is required";
          $Tcpwd=false;
        } else {
              $cpwd = test_input($_POST["cpwd"]);
              $hashp=password_hash($pwd,PASSWORD_DEFAULT);
              $Tcpwd=true;

              if ($pwd!=$cpwd){
                      $ercpwd = "Password do match";
                      $Tcpwd=false;
              }
              
        }

         if ($Tini&&$Tsurname&&$Temail&&$Tcampus&&$Tuser_type&&$Tpwd&&$Tcpwd&&$hashp&&$Tmy_photo) {
                    
            $sql="INSERT INTO `user`(`initials`, `lastname`, `email`, `campus`, `photo`, `password`, `user_type`) VALUES ('$ini','$surname','$email','$campus','$my_photo','$hashp','$user_type')";
            if(mysqli_query($conn,$sql))
                {

                  $get_user_id=mysqli_insert_id($conn);
                  if ($user_type=='Student') {
                    // code...
                     $sql="INSERT INTO `student`(`student_number`, `user_id`) VALUES ('$stud_no','$get_user_id')";
                    if (mysqli_query($conn,$sql)) {
                      // code...
                      $_SESSION['photo']="";
                      echo '<script type="text/javascript">alert("You Succesfully Registered Please Login Your Account"); window.location = "login.php";</script>';
                    }
                  }elseif ($user_type=='Staff') {
                    // code...
                    $_SESSION['photo']="";
                     $sql="INSERT INTO `staff`(`staff_number`, `user_id`) VALUES ('$staff_no','$get_user_id')";
                    if (mysqli_query($conn,$sql)) {
                      // code...
                      echo '<script type="text/javascript">alert("You Succesfully Registered Please Login Your Account"); window.location = "login.php";</script>';
                    }
                  }else{
                    $sql="INSERT INTO `admin`(`user_id`) VALUES ('$get_user_id')";
                    if (mysqli_query($conn,$sql)) {
                      // code...
                      $_SESSION['photo']="";
                      echo '<script type="text/javascript">alert("You Succesfully Registered Please Login Your Account"); window.location = "login.php";</script>';
                    }
                    
                  }
                    

                    
                }else{ echo("<h3>unsuccessfully not registered </h3>".mysqli_error($conn)); }
                          
            }
      }
      
    



      function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
      }
     
      ?> 
      <form action="" method="post" enctype="multipart/form-data">
        <div class="form-group" style="padding: 5px;">
          <label>Register As:</label>
          <p ><input type="radio"  value="Student" name="user_type" onclick="user(this);"  <?php if($user_type=='Student')echo 'checked';?>>Student
          <input type="radio"  value="Staff" name="user_type" onclick="user(this);"  <?php if($user_type=='Staff')echo 'checked';?>>Staff
          <input type="radio"  value="Admin" name="user_type" onclick="user(this);"  <?php if($user_type=='Admin')echo 'checked';?>>Admin</p>
          
          <span class="error"><?php echo $eruser_type;?></span>
        </div>
        <div class="group-inputs">
          <label>Email</label>
          <input type="text" class="form-control" placeholder="Email Addresss" name="email" value="<?php echo $email;?>">
          <span class="error"><?php echo $eremail;?></span>
        </div>
        

       <div class="step-forms">
        <div class="form-group mb-4">
        <label>Password</label>
          <input type="password" class="form-control" placeholder="Enter Password" name="pwd">
          <span class="error"><?php echo $erpwd;?></span>
        </div>
      </div>
      <div class="row rfour">
        <div class="col-md-4 ml-3">
          <button type="submit" class="btn btn-primary mt-3" name="register"><span>Register</span></button>
        </div>
      </div>
      </form>
    </div>
  </div>
</div>

 <script type='text/javascript' src='https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js'></script>

  </body>
</html>

