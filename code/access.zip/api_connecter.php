<?php
$conn2 = mysqli_connect("sql6.freemysqlhosting.net","sql6500524","ZQtWdpzT4P","sql6500524");
//$conn = mysqli_connect("localhost","root","","auto_homebilling");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  //session_start();
/*Server: sql6.freemysqlhosting.net
Name: sql6500524
Username: sql6500524
Password: ZQtWdpzT4P
Port number: 3306*/
?>