<?php
$conn = mysqli_connect("localhost","root","","access_card");
//$conn = mysqli_connect("sql6.freemysqlhosting.net","sql6488539","vVm5jyjRPd8COzm","sql6488539");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  //session_start();

   /*function test_input($data,$conn) {
    $data = mysqli_real_escape_string($conn,$data);
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }*/
  //user:donatrac_donatrack ,user-pass:BBuXHE=m6~Tg ,DB:donatrac_donatrack
?>