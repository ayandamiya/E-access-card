<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>TUT Database</title>
    <!-- load stylesheets -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">  <!-- Google web font "Open Sans" -->
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">                <!-- Font Awesome -->
    <link rel="stylesheet" href="css/bootstrap.min.css">                                      <!-- Bootstrap style -->
    <link rel="stylesheet" type="text/css" href="css/datepicker.css"/>
    <link rel="stylesheet" type="text/css" href="slick/slick.css"/>
    <link rel="stylesheet" type="text/css" href="slick/slick-theme.css"/>
    <link rel="stylesheet" href="css/templatemo-style.css">                                   <!-- Templatemo style -->

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
            
              <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
              <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
          
      </head>

      <body>
        <div class="tm-main-content" id="top">
            <div class="tm-top-bar-bg"></div>    
            

        <div class="tm-page-wrap mx-auto">
           <h1>This is just a mockup for TUT database ,</h1>
           <div class="tm-container-outer tm-position-relative" id="tm-section-4">
                <div>
                    <table border="1" style="width:100%;">
                        <tr>
                            <th>Student/Staff Number</th>
                            <th>user</th>
                        </tr>
                        <?php
                       
                        //include'homeowner/connector.php'; 
                        include'api_connecter.php';
                       /* include'api_connecter.php';
                        include'homeowner/render.php';
                        render_auto_pay($conn);*/

                        $sql2="SELECT * FROM tut_database";
                        $res=mysqli_query($conn2,$sql2);
                        if ($res) {
                            // code...
                            if (mysqli_num_rows($res)==0) {
                                // code...
                                echo '<td>No records</td>';
                            }else{
                                while ($rows=mysqli_fetch_array($res)) {
                                    // code...


                                    ?>
                        <tr>
                            <td><?php echo $rows['individual_no'];?></td>
                            <td><?php echo $rows['user'];?></td>
                        </tr>
                                    <?php
                                }
                            }
                        }
                        ?>
                        
                    </table>
                    <hr>
                    <?php 

                    if(isset($_POST['submit'])){
                        //$card_no=$_POST['card1'].' '.$_POST['card2'].' '.$_POST['card3'].' '.$_POST['card4'];
                        $individual_no=$_POST['individual_no'];
                        $user=$_POST['user'];
//echo "Card is ".$card_no;
                        $sql="INSERT INTO tut_database(`individual_no`, `user`) VALUES ('$individual_no','$user')";
                        if (mysqli_query($conn2,$sql)) {
                            // code...
                            echo "";
                            echo '<script>alert("added successfully."); window.location = "tut.php";</script>';
                        }else{
                            echo 'error! '.mysqli_error($conn2);
                        }
                    }
                    ?>
                    <form action="" method="post">
                        <label>Student/Staff Number</label>
                        <input type="text" id="contact_name" name="individual_no"  placeholder="Student/Staff Number"   required style="width:100%;"/>
                        <!-- <input type="text" id="contact_name" name="card2"  placeholder="2222" minlength="4" maxlength="4"  required style="width:25;"/>
                        <input type="text" id="contact_name" name="card3" placeholder="3333" minlength="4" maxlength="4"  required style="width:25;"/>
                        <input type="text" id="contact_name" name="card4" placeholder="4444" minlength="4" maxlength="4"  required style="width:25;"/>
                        -->
 <br>
                        <label>user</label>
                        <select name="user" required style="width:100%;">
                            <option value="Student">Student</option>
                            <option value="Staff">Staff</option>
                        </select>

                        <input type="submit" name="submit" value="add" required style="width:100%;background-color: black;color: white;"/>
                    </form>
                
                <br>

                <h1><a href="index.html">Go to the system</a></h1>
                </div>
            </div> 

        </div>
    </div> <!-- .main-content -->

    <!-- load JS files -->
    <script src="js/jquery-1.11.3.min.js"></script>             <!-- jQuery (https://jquery.com/download/) -->
    <script src="js/popper.min.js"></script>                    <!-- https://popper.js.org/ -->       
    <script src="js/bootstrap.min.js"></script>                 <!-- https://getbootstrap.com/ -->
    <script src="js/datepicker.min.js"></script>                <!-- https://github.com/qodesmith/datepicker -->
    <script src="js/jquery.singlePageNav.min.js"></script>      <!-- Single Page Nav (https://github.com/ChrisWojcik/single-page-nav) -->
    <script src="slick/slick.min.js"></script>                  <!-- http://kenwheeler.github.io/slick/ -->
    <script src="js/jquery.scrollTo.min.js"></script>           <!-- https://github.com/flesler/jquery.scrollTo -->
              

</body>
</html>