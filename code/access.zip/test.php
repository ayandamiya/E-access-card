s<?php

//require_once(__DIR__ . '/vendor/autoload.php');
/*require('vendor/cloudmersive/cloudmersive_imagerecognition_api_client/vendor/autoload.php');

// Configure API key authorization: Apikey
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('Apikey', '688370a7-d795-4c24-9921-9a14fbbcf03f');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// $config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('Apikey', 'Bearer');

$apiInstance = new Swagger\Client\Api\FaceApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$input_image = "6.jpg"; // \SplFileObject | Image file to perform the operation on; this image can contain one or more faces which will be matched against face provided in the second image.  Common file formats such as PNG, JPEG are supported.
$match_face = "5.jpg"; // \SplFileObject | Image of a single face to compare and match against.*/

/*try {
    $result = $apiInstance->faceCompare($input_image, $match_face);
    print_r($result);
    echo "<br>";
    $result2 = $apiInstance->faceLocate($input_image);
    print_r($result2);
} catch (Exception $e) {
    echo 'Exception when calling FaceApi->faceCompare: ', $e->getMessage(), PHP_EOL;
}
$apiInstance = new Swagger\Client\Api\FaceApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);*/
/*$image_file = "/path/to/file.txt"; // \SplFileObject | Image file to perform the operation on.  Common file formats such as PNG, JPEG are supported.

try {
    $result = $apiInstance->faceLocate($image_file);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling FaceApi->faceLocate: ', $e->getMessage(), PHP_EOL;
}*/

$str='O:40:"Swagger\Client\Model\FaceCompareResponse":1:{s:12:"*container";a:4:{s:10:"successful";b:1;s:5:"faces";a:1:{i:0;O:30:"Swagger\Client\Model\FaceMatch":1:{s:12:"*container";a:6:{s:6:"left_x";i:760;s:5:"top_y";i:701;s:7:"right_x";i:1295;s:8:"bottom_y";i:1236;s:21:"high_confidence_match";b:1;s:11:"match_score";d:0.83623620867729187;}}}s:10:"face_count";i:1;s:13:"error_details";N;}}';

$str2='Swagger\Client\Model\FaceCompareResponse Object ( [container:protected] => Array ( [successful] => 1 [faces] => Array ( [0] => Swagger\Client\Model\FaceMatch Object ( [container:protected] => Array ( [left_x] => 760 [top_y] => 701 [right_x] => 1295 [bottom_y] => 1236 [high_confidence_match] => 1 [match_score] => 0.83623620867729 ) ) ) [face_count] => 1 [error_details] => ) )';


/// string 1
$str_start = strpos($str, "match_score");
echo substr($str, $str_start);
///string 2
echo '<br>';
echo '<br>';
echo 'string 2<br> ';
//echo number_format("0.53623620867729");

function getmatch_score($str2)
{
    $str_start2 = strpos($str2, "match_score");
    $temp_str2=substr($str2, $str_start2);
    $str_end2=strpos($temp_str2, ")");
    //echo $str_end2;
    //echo $temp_str2;
    //echo '('.substr($temp_str2,16,$str_end2-17).')';
    $match_score=floatval(substr($temp_str2,16,$str_end2-17))*100;
    
    //$match_score= floatval(substr($temp_str2,16,$str_end2-17));
    return $match_score;
}
echo 'the face match_score is '.getmatch_score($str2);
function getface_count($str2)
{
    $str_start2 = strpos($str2, "face_count");
    $temp_str2=substr($str2, $str_start2);
    $str_end2=strpos($temp_str2, "[");
    //echo $str_end2;
    //echo $temp_str2;
    //echo '('.substr($temp_str2,16,$str_end2-17).')';
    $face_count=number_format(substr($temp_str2,14,$str_end2-15));
    //$match_score= floatval(substr($temp_str2,16,$str_end2-17));
    return $face_count;
}

echo '<br><br>the face count is '.getface_count($str2);
?>

Student Card Report

Student Date created    Residence   Bus
M Shila 2022-06-18  Yes Yes
NS Wiseman  2022-06-18  Yes Yes